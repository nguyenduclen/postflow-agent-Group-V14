package vn.phutungmaykubota.postflowagent;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.List;
import java.util.Locale;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.regex.Pattern;

/**
 * PostFlow Agent - Chrome/Facebook detector.
 *
 * Important:
 * - Only Chrome/Facebook application packages are accepted as foreground state.
 * - IME/launcher/other app events NEVER overwrite Chrome state.
 * - For Chrome, only the omnibox URL node is inspected.
 */
public class PostFlowAccessibilityService extends AccessibilityService {

    private static volatile PostFlowAccessibilityService INSTANCE;
    private volatile boolean manualPageGroupScanRequested = false;

    public static volatile boolean isRunning = false;
    public static volatile String lastPackage = "";
    public static volatile String lastUrl = "";
    public static volatile boolean facebookDetected = false;
    public static volatile long lastEventTime = 0L;
    public static volatile long lastChromeTime = 0L;
    public static volatile boolean pageDetected = false;
    public static volatile String pageName = "";
    public static volatile String pageUrl = "";
    public static volatile String pageId = "";
    public static volatile String facebookMode = "UNKNOWN";
    public static volatile String visibleGroupsJson = "[]";
    private static final String PREF_LAST_PAGE_NAME = "last_page_name";

    private static final String CHROME = "com.android.chrome";
    private static final String FACEBOOK = "com.facebook.katana";
    private static final String FACEBOOK_LITE = "com.facebook.lite";

    private static final long STATE_TIMEOUT_MS = 24 * 60 * 60 * 1000L;
    // Keep Facebook detection sticky while the user switches Chrome tabs.
    // A new Chrome session is considered only after a long absence, so a
    // normal tab switch/backgrounding does not erase Facebook state.
    private static final long CHROME_SESSION_GAP_MS = 30 * 60 * 1000L;
    private volatile boolean facebookSeenInChromeSession = false;
    private volatile long chromeSessionStartedAt = 0L;
    private static final long URL_PROBE_INTERVAL_MS = 2500L;
    private static final String PREFS = "postflow_agent_final";
    private static final String PREF_LAST_PAGE_URL = "last_page_url";
    private static final String PREF_LAST_PAGE_ID = "last_page_id";

    private volatile long lastUrlProbeAt = 0L;
    private volatile long lastGroupDiscoveryAt = 0L;
    private volatile boolean groupDiscoveryRunning = false;
    private volatile boolean pageContextAnnounced = false;
    private volatile boolean pageIdentityStrong = false;
    private volatile boolean groupContextTrusted = false;
    private volatile boolean groupContextWasPageSpecific = false;
    // V12: a click is only a candidate until the resulting Facebook tree is verified.
    private volatile boolean pageGroupsNavigationAttempted = false;
    private volatile int pageGroupsVerifyAttempts = 0;
    // Which Facebook identity owns the group list currently being discovered.
    // PAGE = groups joined/linked to the active Page; PROFILE = groups joined
    // by the personal Facebook account.
    private volatile String groupDiscoveryOwner = "";
    private volatile int groupDiscoveryPass = 0;
    private volatile int groupDiscoveryNoProgress = 0;
    private volatile String lastGroupTreeSignature = "";
    // Identity hysteresis: Facebook often rebuilds the tree during Page/profile
    // switches. Do not downgrade a verified Page to PROFILE just because one
    // transient tree is missing the Page label.
    private volatile long lastStrongPageSeenAt = 0L;
    private volatile long lastStrongProfileSeenAt = 0L;
    private volatile String prePageGroupsNavigationSignature = "";
    private final LinkedHashMap<String,String> discoveredGroups = new LinkedHashMap<>();

    private static final Pattern FACEBOOK_URL = Pattern.compile(
            "(?i)^(?:https?://)?(?:www\\.)?(?:[a-z0-9-]+\\.)*facebook\\.com(?:[/:?#].*)?$"
    );

    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;
            refreshChromeFromActiveWindow();
            expireStaleState();
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable heartbeat = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;

            new Thread(new Runnable() {
                @Override
                public void run() {
                    AgentSync.heartbeat(PostFlowAccessibilityService.this);
                }
            }, "PostFlowHeartbeat").start();

            handler.postDelayed(this, 5000);
        }
    };

    private final Runnable commandPoller = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;

            new Thread(new Runnable() {
                @Override
                public void run() {
                    AgentCommand.pollAndExecute(PostFlowAccessibilityService.this);
                }
            }, "PostFlowCommandPoll").start();

            handler.postDelayed(this, 5000);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;

        try {
            android.accessibilityservice.AccessibilityServiceInfo info = getServiceInfo();
            if (info != null) {
                info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                        | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                        | AccessibilityEvent.TYPE_VIEW_FOCUSED
                        | AccessibilityEvent.TYPE_WINDOWS_CHANGED;
                info.feedbackType = android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_GENERIC;
                info.flags = android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                        | android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
                        | android.accessibilityservice.AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;
                info.notificationTimeout = 300;
                setServiceInfo(info);
            }
        } catch (Throwable ignored) {
        }

        isRunning = true;
        lastEventTime = System.currentTimeMillis();

        handler.removeCallbacks(poller);
        handler.removeCallbacks(heartbeat);
        handler.removeCallbacks(commandPoller);

        handler.post(poller);
        handler.post(heartbeat);
        handler.post(commandPoller);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        // Android can deliver an event immediately while the service is
        // reconnecting. Treat that event as proof that the service is alive.
        isRunning = true;
        lastEventTime = System.currentTimeMillis();

        String pkg = event.getPackageName() == null
                ? ""
                : event.getPackageName().toString();

        /*
         * CRITICAL:
         * Do NOT call a generic foreground-window detector first.
         * Android may report Launcher/IME/LabanKey while Chrome remains
         * the visible browser. Such events must never erase Chrome state.
         */
        if (CHROME.equals(pkg)) {
            markChrome(event);
            return;
        }

        if (FACEBOOK.equals(pkg) || FACEBOOK_LITE.equals(pkg)) {
            lastPackage = pkg;
            facebookDetected = true;
            lastUrl = "";
            lastChromeTime = System.currentTimeMillis();
            return;
        }

        /*
         * Ignore Launcher, keyboard, System UI and every unrelated package.
         * This is the key fix for the previous "com.android.launcher3" bug.
         */
        expireStaleState();
    }

    private void beginOrKeepChromeSession(long now) {
        if (chromeSessionStartedAt == 0L
                || (lastChromeTime > 0L && now - lastChromeTime > CHROME_SESSION_GAP_MS)) {
            chromeSessionStartedAt = now;
            facebookSeenInChromeSession = false;
            facebookDetected = false;
            pageDetected = false;
            pageName = "";
            pageUrl = "";
            pageId = "";
            facebookMode = "UNKNOWN";
        }
    }

    private void markChrome(AccessibilityEvent event) {
        long now = System.currentTimeMillis();

        beginOrKeepChromeSession(now);
        lastPackage = CHROME;
        lastChromeTime = now;

        AccessibilityNodeInfo source = null;

        try {
            source = event.getSource();

            if (source != null) {
                String url = findChromeUrlBar(source);
                if (!url.isEmpty()) updateChromeUrl(url);
                inspectFacebookContext(source);
                return;
            }
        } catch (Throwable ignored) {
        } finally {
            if (source != null) {
                try {
                    source.recycle();
                } catch (Throwable ignored) {
                }
            }
        }

        /*
         * Event is definitely from Chrome even if Chrome temporarily hides
         * or rebuilds the URL bar. Keep Chrome alive and keep the last known
         * Facebook URL instead of replacing it with Launcher/IME.
         */
        facebookDetected = facebookDetected && isFacebookUrl(lastUrl);
    }

    /**
     * Poll Chrome's actual active application window.
     * This is only used to refresh Chrome state, never to replace it with
     * Launcher/IME/another app.
     */
    private void refreshChromeFromActiveWindow() {
        if (!isRunning) return;

        AccessibilityNodeInfo root = null;

        try {
            root = getRootInActiveWindow();

            // IMPORTANT: getRootInActiveWindow() can temporarily return null
            // on Android/Chrome mobile. Do NOT return here. We must still
            // inspect AccessibilityWindowInfo below, otherwise Chrome is
            // reported as "not detected" even while it is on screen.
            if (root != null) {
                CharSequence p = root.getPackageName();
                String pkg = p == null ? "" : p.toString();

                if (CHROME.equals(pkg)) {
                    long now = System.currentTimeMillis();
                    beginOrKeepChromeSession(now);
                    lastPackage = CHROME;
                    lastChromeTime = now;
                    String url = findChromeUrlBar(root);
                    if (!url.isEmpty()) updateChromeUrl(url);
                    inspectFacebookContext(root);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (root != null) {
                try {
                    root.recycle();
                } catch (Throwable ignored) {
                }
            }
        }

        // ALWAYS inspect accessibility windows. This is the fallback for
        // Chrome builds where getRootInActiveWindow() is null or stale.
        refreshChromeFromWindows();
    }

    private void refreshChromeFromWindows() {
        List<AccessibilityWindowInfo> windows;

        try {
            windows = getWindows();
        } catch (Throwable ignored) {
            return;
        }

        if (windows == null) return;

        // Chrome may expose the omnibox as the focused window while the
        // Facebook document is exposed by another Chrome accessibility
        // window.  Inspect ALL Chrome application windows for Facebook/Page
        // context, but only an active/focused Chrome window is allowed to
        // establish that Chrome itself is online.
        boolean chromeWindowFound = false;
        for (AccessibilityWindowInfo window : windows) {
            if (window == null || window.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
            AccessibilityNodeInfo r = null;
            try {
                r = window.getRoot();
                if (r == null || !CHROME.equals(packageName(r))) continue;
                chromeWindowFound = true;
                long now = System.currentTimeMillis();
                if (window.isActive() || window.isFocused()) {
                    beginOrKeepChromeSession(now);
                    lastPackage = CHROME;
                    lastChromeTime = now;
                }
                // Always inspect Chrome's document tree. The current URL is
                // read first so a non-Facebook tab cannot masquerade as a
                // Facebook Page merely because the Panel itself contains the
                // words Facebook/Page/Group.
                String url = findChromeUrlBar(r);
                if (!url.isEmpty() && (window.isActive() || window.isFocused())) {
                    updateChromeUrl(url);
                }
                inspectFacebookContext(r);
            } catch (Throwable ignored) {
            } finally {
                if (r != null) try { r.recycle(); } catch (Throwable ignored) {}
            }
        }

        if (!chromeWindowFound) return;
        return;
    }

        /* old single-window implementation intentionally removed */
        /*
        for (AccessibilityWindowInfo window : new AccessibilityWindowInfo[]{best}) {
            if (window == null) continue;

            AccessibilityNodeInfo root = null;

            try {
                root = window.getRoot();
                if (root == null) continue;

                CharSequence p = root.getPackageName();
                String pkg = p == null ? "" : p.toString();

                if (!CHROME.equals(pkg)) continue;

                long now = System.currentTimeMillis();
                beginOrKeepChromeSession(now);
                lastPackage = CHROME;
                lastChromeTime = now;
                inspectFacebookContext(root);

                String url = findChromeUrlBar(root);
                if (!url.isEmpty()) {
                    updateChromeUrl(url);
                    return;
                }
            } catch (Throwable ignored) {
            } finally {
                if (root != null) {
                    try {
                        root.recycle();
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
    }

        */

    /**
     * Only search for Chrome's omnibox resource id.
     * We never recursively read arbitrary Facebook page text.
     */
    /**
     * Chrome Android can display only "facebook.com" in the omnibox even
     * when the real tab URL contains /pages/... or /groups/....  The
     * accessibility tree may expose only the shortened display value while
     * the URL bar is not focused.  When that happens, briefly focus/copy the
     * URL-bar value and read the clipboard.  We accept the clipboard only if
     * it is a specific Facebook URL, never passwords/cookies/page content.
     */
    private String packageName(AccessibilityNodeInfo node) {
        if (node == null || node.getPackageName() == null) return "";
        return node.getPackageName().toString();
    }

    private AccessibilityNodeInfo findChromeUrlBarNode(AccessibilityNodeInfo node) {
        if (node == null) return null;
        try {
            CharSequence id = node.getViewIdResourceName();
            if (id != null) {
                String resource = id.toString().toLowerCase(Locale.US);
                if (resource.contains("url_bar") || resource.endsWith(":id/url_bar")) {
                    return node;
                }
            }

            int count = node.getChildCount();
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child = null;
                try {
                    child = node.getChild(i);
                    AccessibilityNodeInfo found = findChromeUrlBarNode(child);
                    if (found != null) {
                        // Do not recycle a node returned to the caller.
                        child = null;
                        return found;
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (child != null) {
                        try { child.recycle(); } catch (Throwable ignored) {}
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private boolean isFacebookRootUrl(String value) {
        if (value == null) return false;
        String s = value.trim();
        return s.matches("(?i)^https?://(?:www\\.)?facebook\\.com/?$");
    }

    private boolean isSpecificFacebookUrl(String value) {
        if (value == null) return false;
        String s = value.trim();
        if (!isFacebookUrl(s) || isFacebookRootUrl(s)) return false;
        try {
            android.net.Uri uri = android.net.Uri.parse(s);
            String path = uri.getPath() == null ? "" : uri.getPath().trim();
            if (path.isEmpty() || "/".equals(path)) return false;
            String first = path.replaceFirst("^/", "").split("/", 2)[0].toLowerCase(Locale.US);
            return !first.isEmpty();
        } catch (Throwable ignored) {
            return false;
        }
    }

    private String findChromeUrlBar(AccessibilityNodeInfo node) {
        if (node == null) return "";

        try {
            CharSequence id = node.getViewIdResourceName();

            if (id != null) {
                String resource = id.toString().toLowerCase(Locale.US);

                if (resource.contains("url_bar") || resource.endsWith(":id/url_bar")) {
                    // IMPORTANT: On Chrome Android the visible text can be only
                    // "facebook.com" while contentDescription contains the full
                    // current URL (including /pages/... or other path).
                    // Prefer the full URL candidate so Panel follows navigation
                    // inside Facebook instead of staying at https://facebook.com.
                    String value = bestUrlCandidate(node);
                    if (!value.isEmpty()) return value;
                }
            }

            int count = node.getChildCount();
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child = null;
                try {
                    child = node.getChild(i);
                    if (child != null) {
                        String found = findChromeUrlBar(child);
                        if (!found.isEmpty()) return found;
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (child != null) {
                        try { child.recycle(); } catch (Throwable ignored) {}
                    }
                }
            }
        } catch (Throwable ignored) {
        }

        return "";
    }

    private String bestUrlCandidate(AccessibilityNodeInfo node) {
        String description = node.getContentDescription() == null
                ? "" : node.getContentDescription().toString().trim();
        String text = node.getText() == null
                ? "" : node.getText().toString().trim();
        String hint = node.getHintText() == null
                ? "" : node.getHintText().toString().trim();

        // 1) Prefer a complete http(s) URL from contentDescription.
        if (isCompleteHttpUrl(description)) return description;
        if (isCompleteHttpUrl(text)) return text;
        if (isCompleteHttpUrl(hint)) return hint;

        // 2) Then accept facebook.com/path from any exposed property.
        if (looksLikeUrlOrFacebook(description)) return description;
        if (looksLikeUrlOrFacebook(text)) return text;
        if (looksLikeUrlOrFacebook(hint)) return hint;

        return "";
    }

    private boolean isCompleteHttpUrl(String value) {
        if (value == null) return false;
        String s = value.trim();
        return s.matches("(?i)^https?://[^\\s]+$");
    }

    private String nodeValue(AccessibilityNodeInfo node) {
        String best = bestUrlCandidate(node);
        if (!best.isEmpty()) return best;
        return "";
    }

    private boolean looksLikeUrlOrFacebook(String value) {
        if (value == null) return false;

        String s = value.trim();

        if (s.isEmpty()) return false;

        return s.matches("(?i)^https?://.*")
                || s.matches("(?i)^(?:www\\.)?(?:[a-z0-9-]+\\.)*facebook\\.com(?:/.*)?$")
                || s.matches("(?i)^facebook\\.com(?:/.*)?$");
    }


    /**
     * Detect Facebook context from Chrome's accessibility tree, not from the
     * omnibox URL. Facebook mobile may keep the URL at facebook.com while the
     * user has switched into a Page context.
     */
    private void inspectFacebookContext(AccessibilityNodeInfo root) {
        if (root == null || !CHROME.equals(packageName(root))) return;

        // IMPORTANT: the PostFlow Panel is also opened in Chrome and contains
        // words such as "Facebook", "Page" and "Group".  Never interpret the
        // Panel as Facebook. Check the URL currently exposed by THIS Chrome
        // window or require several independent Facebook UI signals.
        String currentUrl = findChromeUrlBar(root);
        ArrayList<String> texts = new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collectUsefulNodes(root, texts, nodes, 0);

        boolean facebookDocument = isFacebookDocumentTree(texts, currentUrl);
        if (!facebookDocument) {
            for (AccessibilityNodeInfo n : nodes) {
                try { n.recycle(); } catch (Throwable ignored) {}
            }
            return;
        }

        String detectedName = "";
        int bestScore = 0;
        for (String t : texts) {
            String n = extractPageName(t);
            if (!n.isEmpty()) {
                int score = pageNameScore(t, n);
                if (score > bestScore) {
                    bestScore = score;
                    detectedName = n;
                }
            }
        }

        // Facebook mobile often keeps the omnibox at facebook.com when the
        // user has switched from a personal profile to a Page.  The Page
        // identity is therefore inferred from the Facebook UI itself.
        String inferredPageName = inferPageNameFromFacebookUi(texts);
        if (detectedName.isEmpty() && !inferredPageName.isEmpty()) {
            detectedName = inferredPageName;
            bestScore = Math.max(bestScore, 85);
        }

        // Facebook mobile may expose the real Page URL only inside an
        // accessibility link/href while the Chrome omnibox remains simply
        // facebook.com. Treat that as strong Page identity evidence.
        String treePageUrl = findSpecificPageUrlInTexts(texts);
        String treePageName = inferPageNameFromFacebookUrl(treePageUrl);
        if (detectedName.isEmpty() && !treePageName.isEmpty()) {
            detectedName = treePageName;
            bestScore = Math.max(bestScore, 100);
        }

        // IMPORTANT: "Chuyển sang <Page> / Switch to <Page>" is a list of
        // available Pages, NOT proof that the current Facebook identity is
        // that Page. V9 treated this menu as an active Page and consequently
        // lost the real identity/page name. Only accept an ACTIVE Page signal.
        String urlPageName = inferPageNameFromFacebookUrl(currentUrl);
        if (detectedName.isEmpty() && !urlPageName.isEmpty()) {
            detectedName = urlPageName;
            bestScore = Math.max(bestScore, 100);
        }

        pageIdentityStrong = hasActivePageIdentitySignal(root, texts, inferredPageName, detectedName, currentUrl)
                || !treePageUrl.isEmpty();
        boolean profileSignal = hasStrongPersonalIdentitySignal(texts);
        boolean explicitProfileSignal = hasExplicitProfileIdentitySignal(texts, currentUrl);

        if (pageIdentityStrong) lastStrongPageSeenAt = System.currentTimeMillis();
        if (profileSignal) lastStrongProfileSeenAt = System.currentTimeMillis();

        // Identity priority is deliberate: an ACTIVE Page wins; otherwise the
        // current identity is PROFILE. Menu entries such as "Chuyển sang ..."
        // are never enough to switch the state to PAGE.
        boolean pageSignal = pageIdentityStrong && (bestScore >= 60
                || hasActivePageContextSignal(texts)
                || !treePageUrl.isEmpty());

        // Hysteresis is critical. A transient Facebook tree during Page
        // navigation must not turn an already verified Page into PROFILE.
        // Only an explicit personal-profile surface may force the downgrade.
        if (!pageSignal && pageDetected && !explicitProfileSignal
                && (System.currentTimeMillis() - lastStrongPageSeenAt) < 15000L) {
            pageSignal = true;
        }

        if (pageSignal) {
            boolean wasPage = pageDetected;
            pageDetected = true;
            facebookMode = "PAGE";

            String previousPageName = pageName == null ? "" : pageName;

            if (!detectedName.isEmpty()) {
                pageName = cleanUiText(detectedName);
                savePageName(pageName);
            } else if (pageName.isEmpty()) {
                pageName = getSavedPageName();
            }
            if (!treePageUrl.isEmpty()) {
                pageUrl = treePageUrl;
                savePageUrl(treePageUrl);
            }

            // A real Page switch must start a fresh Group discovery. The
            // previous implementation only discovered once per service
            // lifetime, so switching Page A -> Page B kept the old list.
            boolean pageChanged = !pageName.isEmpty()
                    && !pageName.equalsIgnoreCase(previousPageName);

            if (pageChanged) {
                discoveredGroups.clear();
                visibleGroupsJson = "[]";
                pageContextAnnounced = false;
                pageIdentityStrong = false;
                pageId = "";
                pageUrl = "";
                savePageId("");
                savePageUrl("");
                groupContextTrusted = false;
                groupContextWasPageSpecific = false;
                pageGroupsNavigationAttempted = false;
                pageGroupsVerifyAttempts = 0;
                groupDiscoveryOwner = "";
                groupDiscoveryPass = 0;
                groupDiscoveryNoProgress = 0;
                lastGroupTreeSignature = "";
                prePageGroupsNavigationSignature = "";
                lastGroupDiscoveryAt = 0L;
                pageIdentityStrong = hasStrongPageIdentitySignal(texts, inferredPageName, detectedName);
            }

            // Keep discovery automatic. It is triggered by the UI transition
            // to PAGE, never by the omnibox URL.
            if (!wasPage || !pageContextAnnounced || pageChanged || discoveredGroups.isEmpty()
                    || !groupDiscoveryOwner.equals("PAGE")) {
                if (!groupDiscoveryOwner.equals("PAGE")) {
                    groupDiscoveryRunning = false;
                    discoveredGroups.clear();
                    visibleGroupsJson = "[]";
                    groupContextTrusted = false;
                    groupContextWasPageSpecific = false;
                    pageGroupsNavigationAttempted = false;
                    pageGroupsVerifyAttempts = 0;
                    groupDiscoveryPass = 0;
                    groupDiscoveryNoProgress = 0;
                    lastGroupTreeSignature = "";
                    prePageGroupsNavigationSignature = "";
                }
                pageContextAnnounced = true;
                groupDiscoveryOwner = "PAGE";
                scheduleAutomaticPageGroupDiscovery();
            }
        } else {
            // Facebook document detected but no strong Page identity is
            // visible. Treat the active identity as the personal account and
            // discover its Groups list. This is intentional: the Agent follows
            // the identity Facebook exposes, not a stale Page name saved earlier.
            // Do not keep a stale Page identity as the current identity.
            pageDetected = false;
            facebookMode = "PROFILE";
            pageIdentityStrong = false;

            boolean ownerChanged = !groupDiscoveryOwner.equals("PROFILE");
            if (ownerChanged) {
                groupDiscoveryRunning = false;
                // Never mix Page groups with personal-account groups.
                    discoveredGroups.clear();
                    visibleGroupsJson = "[]";
                    groupContextTrusted = false;
                    groupContextWasPageSpecific = false;
                    pageGroupsNavigationAttempted = false;
                    pageGroupsVerifyAttempts = 0;
                    groupDiscoveryPass = 0;
                    groupDiscoveryNoProgress = 0;
                    lastGroupTreeSignature = "";
                    prePageGroupsNavigationSignature = "";
            }
            groupDiscoveryOwner = "PROFILE";
            pageName = "";
            pageId = "";
            pageUrl = "";
            // V13: Profile mode never scans the personal Groups list.
            // This Agent feature is specifically for Groups associated with
            // the currently active Facebook Page. Keeping PROFILE discovery
            // disabled prevents personal Groups from being mixed into Page data.
            if (ownerChanged) {
                groupDiscoveryRunning = false;
                groupContextTrusted = false;
                visibleGroupsJson = "[]";
            }
        }

        String detectedPageId = pageDetected ? extractPageId(texts, lastUrl, pageUrl) : "";
        if (!detectedPageId.isEmpty()) {
            pageId = detectedPageId;
            savePageId(pageId);
        } else if (pageId.isEmpty()) {
            pageId = getSavedPageId();
        }

        // Only Page-Groups discovery is authoritative. A random /groups/...
        // link appearing in a Page feed is NOT evidence that the Page belongs
        // to that Group, so it is ignored unless we are inside the verified
        // Page Groups context.
        // V14: discoveredGroups is the ONLY authoritative Group source.
        // Never promote a /groups/ URL merely because it appeared in the
        // current Accessibility tree, feed, menu, ad, or screen.
        LinkedHashMap<String,String> groups = new LinkedHashMap<>(discoveredGroups);
        try {
            JSONArray arr = new JSONArray();
            for (Map.Entry<String,String> e : groups.entrySet()) {
                JSONObject o = new JSONObject();
                o.put("url", e.getKey());
                o.put("name", e.getValue());
                o.put("owner_type", groupDiscoveryOwner.isEmpty() ? "UNKNOWN" : groupDiscoveryOwner);
                if (pageDetected) o.put("page_name", pageName);
                arr.put(o);
            }
            visibleGroupsJson = arr.toString();
        } catch (Throwable ignored) {}

        for (AccessibilityNodeInfo n : nodes) {
            try { n.recycle(); } catch (Throwable ignored) {}
        }
    }

    /**
     * Automatically discover the Groups associated with the currently active
     * Facebook Page. The user only has to switch from Profile to Page.
     *
     * We never touch Chrome's omnibox and never use loadUrl(). The Agent only
     * uses accessibility actions on Facebook's own navigation controls.
     */
    private void scheduleAutomaticProfileGroupDiscovery() {
        long now = System.currentTimeMillis();
        if (!isRunning || !isChromeActive() || pageDetected) return;
        if (groupDiscoveryRunning) return;
        if (now - lastGroupDiscoveryAt < 5000L) return;

        lastGroupDiscoveryAt = now;
        groupDiscoveryRunning = true;
        groupDiscoveryOwner = "PROFILE";
        requestMembershipGroupsAsync("PROFILE");
    }

    private void scheduleAutomaticPageGroupDiscovery() {
        long now = System.currentTimeMillis();
        if (!pageDetected || !isChromeActive()) return;
        if (groupDiscoveryRunning) return;
        if (now - lastGroupDiscoveryAt < 12000L) return;

        lastGroupDiscoveryAt = now;
        groupDiscoveryRunning = true;
        groupDiscoveryOwner = "PAGE";
        requestMembershipGroupsAsync("PAGE");
    }

    /** V14: membership-first. No screen/text/tree Group scanning is allowed. */
    private void requestMembershipGroupsAsync(final String ownerType) {
        new Thread(new Runnable() {
            @Override public void run() {
                GroupMembershipProvider.Result result = GroupMembershipProvider.fetch(
                        PostFlowAccessibilityService.this, ownerType, pageName, pageId, pageUrl);
                handler.post(new Runnable() {
                    @Override public void run() {
                        try {
                            if (!result.ok) {
                                discoveredGroups.clear();
                                visibleGroupsJson = "[]";
                                groupContextTrusted = false;
                                return;
                            }
                            discoveredGroups.clear();
                            for (GroupMembershipProvider.GroupRecord g : result.groups.values()) {
                                if (g.url != null && !g.url.isEmpty() && g.url.matches("(?i)^https://(?:www\\.)?facebook\\.com/groups/[^/?#]+/?(?:[?#].*)?$")) {
                                    discoveredGroups.put(g.url, g.name.isEmpty() ? "Facebook Group" : g.name);
                                }
                            }
                            groupContextTrusted = !discoveredGroups.isEmpty();
                            updateVisibleGroupsFromDiscovered();
                        } finally {
                            groupDiscoveryRunning = false;
                            groupDiscoveryPass = 0;
                            groupDiscoveryNoProgress = 0;
                        }
                    }
                });
            }
        }, "PostFlowGroupMembership").start();
    }

    /**
     * Automatic Page -> Groups discovery.
     *
     * The user does NOT have to open a Group.  The Agent may open the
     * Page's own Groups list through an Accessibility click, collect the
     * Group cards/links, then return to the Page.  No password, cookie,
     * WebView or Chrome storage is accessed.
     */
    /**
     * Page -> Groups discovery state machine.
     *
     * Rules:
     * 1) Never click the personal-account "Groups/Nhóm" destination merely
     *    because the word exists. A candidate must be Page-specific or be
     *    inside a subtree that also contains the current Page name.
     * 2) After a click, verify that the destination is a Page Groups context
     *    before harvesting names. This prevents importing the user's personal
     *    groups by mistake.
     * 3) Once inside a trusted Page Groups context, harvest visible cards,
     *    scroll every scrollable container, deduplicate, and stop only after
     *    three consecutive passes make no progress and no scroll action is
     *    possible.
     * 4) If Accessibility never exposes a Page Groups destination, do not
     *    invent a list. The Agent keeps the Page data and reports only groups
     *    actually exposed by the tree.
     */
    /**
     * Discover groups joined by the personal Facebook account. This is a
     * separate state machine from Page -> Groups so the Agent never mixes
     * personal membership with Page membership.
     */
    // V14 deliberately contains no Group screen navigation or Accessibility
    // Group harvesting. Membership data comes only from GroupMembershipProvider.

    private boolean hasExplicitProfileIdentitySignal(ArrayList<String> texts, String currentUrl) {
        // V13: menu entries such as "Trang cá nhân của bạn" and "Chuyển sang
        // trang cá nhân" are NOT proof that the current identity is PROFILE.
        // They are merely available destinations in Facebook's identity switcher.
        // Only explicit active-profile controls are allowed to downgrade a
        // verified Page.
        if (texts == null) return false;
        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw).toLowerCase(Locale.US);
            if (s.contains("đang sử dụng facebook với tư cách cá nhân")
                    || s.contains("đang dùng facebook với tư cách cá nhân")
                    || s.contains("using facebook as your profile")
                    || s.contains("using facebook as a person")
                    || s.contains("current profile")
                    || s.contains("profile hiện tại")
                    || s.contains("trang cá nhân hiện tại")) return true;
        }
        return false;
    }

    private String findSpecificPageUrlInTexts(ArrayList<String> texts) {
        if (texts == null) return "";
        Pattern p = Pattern.compile("(?i)https?://(?:www\\.)?facebook\\.com/pages/[^\\s\\]\\)<>]+") ;
        Pattern q = Pattern.compile("(?i)https?://(?:www\\.)?facebook\\.com/[^/?#\\s]+[?&](?:id|page_id)=\\d{5,30}(?:&[^\\s]+)?");
        for (String raw : texts) {
            if (raw == null) continue;
            java.util.regex.Matcher m = p.matcher(raw);
            if (m.find() && isSpecificFacebookPageUrl(m.group(0))) return m.group(0);
            m = q.matcher(raw);
            if (m.find() && isSpecificFacebookPageUrl(m.group(0))) return m.group(0);
        }
        return "";
    }

    private void updateVisibleGroupsFromDiscovered() {
        String old = visibleGroupsJson;

        try {
            JSONArray a = new JSONArray();

            for (Map.Entry<String,String> e : discoveredGroups.entrySet()) {
                JSONObject o = new JSONObject();
                String key = e.getKey();
                String name = e.getValue();

                if (key.startsWith("name:")) {
                    o.put("url", "");
                    o.put("name", name);
                } else {
                    o.put("url", key);
                    o.put("name", name);
                }

                a.put(o);
            }

            visibleGroupsJson = a.toString();
        } catch (Throwable ignored) {
            return;
        }

        if (!visibleGroupsJson.equals(old)) {
            // Do not wait for the 15-second heartbeat. Panel should receive
            // the Group list as soon as Facebook exposes a new card.
            new Thread(new Runnable() {
                @Override public void run() {
                    AgentSync.heartbeat(PostFlowAccessibilityService.this);
                }
            }, "PostFlowGroupSync").start();
        }
    }

    private void inspectCurrentChromeAgain() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && CHROME.equals(packageName(root))) {
                inspectFacebookContext(root);
                String url = findChromeUrlBar(root);
                if (!url.isEmpty()) updateChromeUrl(url);
                try { root.recycle(); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    private void collectUsefulNodes(AccessibilityNodeInfo node, ArrayList<String> texts,
                                    ArrayList<AccessibilityNodeInfo> nodes, int depth) {
        if (node == null || depth > 35 || texts.size() > 1200) return;
        try {
            String t = node.getText() == null ? "" : node.getText().toString().trim();
            String d = node.getContentDescription() == null ? "" : node.getContentDescription().toString().trim();
            if (!t.isEmpty()) texts.add(t);
            if (!d.isEmpty()) texts.add(d);
            if (!t.isEmpty() || !d.isEmpty()) nodes.add(AccessibilityNodeInfo.obtain(node));
            int count = node.getChildCount();
            for (int i=0;i<count;i++) {
                AccessibilityNodeInfo c=null;
                try { c=node.getChild(i); if(c!=null) collectUsefulNodes(c,texts,nodes,depth+1); }
                catch(Throwable ignored) {}
                finally { if(c!=null) try{c.recycle();}catch(Throwable ignored){} }
            }
        } catch(Throwable ignored) {}
    }

    /**
     * Infer the currently selected Facebook Page from the mobile composer and
     * Page UI.  Facebook frequently renders the Page name next to the
     * "What's on your mind?" composer even though the omnibox remains
     * facebook.com.  This is intentionally UI-only; no cookies/passwords are
     * accessed.
     */
    private boolean isFacebookDocumentTree(ArrayList<String> texts, String currentUrl) {
        if (isFacebookUrl(currentUrl)) return true;
        if (texts == null) return false;

        int strong = 0;
        int facebookWord = 0;
        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw).toLowerCase(Locale.US);
            if (s.contains("facebook.com") || s.equals("facebook") || s.contains("facebook ")) facebookWord++;
            if (s.contains("bạn đang nghĩ gì") || s.contains("ban dang nghi gi")
                    || s.contains("what's on your mind") || s.contains("what’s on your mind")) strong++;
            if (s.equals("bảng tin") || s.equals("news feed") || s.equals("feed")
                    || s.equals("reels") || s.equals("marketplace") || s.equals("friends")
                    || s.equals("bạn bè") || s.equals("notifications") || s.equals("thông báo")
                    || s.equals("groups") || s.equals("nhóm")) strong++;
            if (s.contains("professional dashboard") || s.contains("bảng điều khiển chuyên nghiệp")
                    || s.contains("using facebook as") || s.contains("đang sử dụng facebook với tư cách")
                    || s.contains("switch to a page") || s.contains("chuyển sang trang")) strong += 2;
        }
        return strong >= 2 && (facebookWord > 0 || strong >= 4);
    }

    private boolean hasStrongPersonalIdentitySignal(ArrayList<String> texts) {
        if (texts == null) return false;
        boolean explicitProfile = false;
        boolean profileNavigation = false;
        boolean personalControls = false;

        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw).toLowerCase(Locale.US);

            if (s.contains("trang cá nhân") || s.contains("trang ca nhan")
                    || s.contains("your profile") || s.contains("my profile")
                    || s.contains("personal profile") || s.contains("chỉnh sửa trang cá nhân")
                    || s.contains("chinh sua trang ca nhan") || s.contains("edit profile")
                    || s.contains("switch to profile") || s.contains("chuyển sang trang cá nhân")) {
                explicitProfile = true;
            }
            if (s.equals("bạn bè") || s.equals("ban be") || s.equals("friends")
                    || s.equals("bài viết") || s.equals("bai viet")
                    || s.equals("posts") || s.equals("about") || s.equals("giới thiệu")) {
                profileNavigation = true;
            }
            if (s.contains("add story") || s.contains("thêm tin") || s.contains("them tin")
                    || s.contains("edit public details") || s.contains("chỉnh sửa chi tiết công khai")) {
                personalControls = true;
            }
        }

        return explicitProfile || (profileNavigation && personalControls);
    }

    private boolean hasStrongPageIdentitySignal(ArrayList<String> texts, String inferred, String detected) {
        if (texts == null) return false;
        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw).toLowerCase(Locale.US);
            // These phrases describe the CURRENT identity, not a menu option.
            if (s.contains("đang sử dụng facebook với tư cách")
                    || s.contains("đang dùng facebook với tư cách")
                    || s.contains("using facebook as")
                    || s.contains("current page")
                    || s.contains("trang hiện tại")
                    || s.contains("page hiện tại")) return true;
            // A Page dashboard is an active Page surface.
            if (s.contains("professional dashboard")
                    || s.contains("bảng điều khiển chuyên nghiệp")
                    || s.contains("professional tools")
                    || s.contains("công cụ chuyên nghiệp")
                    || s.contains("manage page")
                    || s.contains("quản lý trang")
                    || s.contains("edit page")
                    || s.contains("chỉnh sửa trang")
                    || s.contains("page settings")
                    || s.contains("cài đặt trang")
                    || s.contains("create post")
                    || s.contains("tạo bài viết")) return true;
        }
        // V12: never infer an active Page merely because a Page name was
        // found in a switcher/menu/composer candidate. Active identity must
        // have an explicit signal or a specific Page URL.
        return false;
    }

    /** Active Page evidence only. Never treats "Chuyển sang / Switch to" as active. */
    private boolean hasActivePageIdentitySignal(AccessibilityNodeInfo root, ArrayList<String> texts,
                                                String inferred, String detected, String currentUrl) {
        if (isSpecificFacebookPageUrl(currentUrl)) return true;
        if (hasStrongPageIdentitySignal(texts, inferred, detected)) return true;

        if (root != null) {
            ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
            try {
                collectUsefulNodes(root, new ArrayList<String>(), nodes, 0);
                for (AccessibilityNodeInfo n : nodes) {
                    if (n == null) continue;
                    String t = n.getText() == null ? "" : cleanUiText(n.getText().toString());
                    String d = n.getContentDescription() == null ? "" : cleanUiText(n.getContentDescription().toString());
                    String combined = (t + " " + d).toLowerCase(Locale.US);
                    if (combined.contains("chuyển sang ") || combined.contains("switch to ")) continue;
                    if ((n.isSelected() || n.isChecked()) && isPlausiblePageName(t)) return true;
                    if (n.isAccessibilityFocused() && isPlausiblePageName(t)
                            && (combined.contains("page") || combined.contains("trang")
                            || combined.contains("professional"))) return true;
                }
            } finally {
                for (AccessibilityNodeInfo n : nodes) try { n.recycle(); } catch (Throwable ignored) {}
            }
        }
        return false;
    }

    private boolean hasActivePageContextSignal(ArrayList<String> texts) {
        if (texts == null) return false;
        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw).toLowerCase(Locale.US);
            if (s.contains("đang sử dụng facebook với tư cách")
                    || s.contains("đang dùng facebook với tư cách")
                    || s.contains("using facebook as")
                    || s.contains("professional dashboard")
                    || s.contains("bảng điều khiển chuyên nghiệp")
                    || s.contains("trang hiện tại")
                    || s.contains("current page")) return true;
        }
        return false;
    }

    private String inferPageNameFromFacebookUi(ArrayList<String> texts) {
        if (texts == null) return "";

        String[] patterns = {
                "(?i)^(.{2,120})\\s+(?:ơi,?\\s*)?(?:bạn đang nghĩ gì|ban dang nghi gi).*$",
                "(?i)^(.{2,120})\\s+(?:ơi,?\\s*)?(?:what(?:'|’)s on your mind).*$",
                "(?i)^(.{2,120})\\s+(?:đang nghĩ gì|dang nghi gi).*$",
                "(?i).*?(?:page|trang)\\s*[:\\-]\\s*(.{2,120})$",
                "(?i).*?(?:professional dashboard|bảng điều khiển chuyên nghiệp)\\s*[:\\-]?\\s*(.{2,120})$"
        };

        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw);
            if (s.length() < 3 || s.length() > 220) continue;

            for (String pattern : patterns) {
                try {
                    java.util.regex.Matcher m = Pattern.compile(pattern).matcher(s);
                    if (m.matches()) {
                        String candidate = cleanUiText(m.group(1));
                        candidate = candidate.replaceFirst(
                                "(?i)^(?:bài viết|bài viết của|post|page)\\s*[:\\-]\\s*", "");
                        if (isPlausiblePageName(candidate)) return candidate;
                    }
                } catch (Throwable ignored) {}
            }
        }

        // Common Facebook Page composer wording can be exposed as separate
        // nodes. Look for a short name immediately before/after the composer.
        for (int i = 0; i < texts.size(); i++) {
            String t = cleanUiText(texts.get(i));
            String lower = t.toLowerCase(Locale.US);
            if (lower.contains("bạn đang nghĩ gì") || lower.contains("ban dang nghi gi")
                    || lower.contains("what's on your mind") || lower.contains("what’s on your mind")) {
                for (int j = Math.max(0, i - 3); j <= Math.min(texts.size() - 1, i + 3); j++) {
                    String candidate = cleanUiText(texts.get(j));
                    if (!candidate.equals(t) && isPlausiblePageName(candidate)) {
                        return candidate;
                    }
                }
            }
        }

        // V13: Page controls are often exposed separately from the Page name.
        // If the current tree contains a strong Page control, use the nearest
        // plausible non-menu label as the active Page name. Never use a
        // "Chuyển sang / Switch to" entry.
        boolean pageControls = false;
        for (String raw : texts) {
            if (raw == null) continue;
            String l = cleanUiText(raw).toLowerCase(Locale.US);
            if (l.contains("professional dashboard") || l.contains("bảng điều khiển chuyên nghiệp")
                    || l.contains("professional tools") || l.contains("công cụ chuyên nghiệp")
                    || l.contains("manage page") || l.contains("quản lý trang")
                    || l.contains("edit page") || l.contains("chỉnh sửa trang")) {
                pageControls = true;
                break;
            }
        }
        if (pageControls) {
            for (String raw : texts) {
                String candidate = cleanUiText(raw);
                String lower = candidate.toLowerCase(Locale.US);
                if (lower.contains("chuyển sang ") || lower.contains("switch to ")
                        || lower.equals("facebook") || lower.equals("trang") || lower.equals("page")
                        || lower.contains("dashboard") || lower.contains("bảng điều khiển")) continue;
                if (isPlausiblePageName(candidate) && candidate.length() <= 100) return candidate;
            }
        }
        return "";
    }

    private boolean isPlausiblePageName(String value) {
        if (value == null) return false;
        String s = cleanUiText(value);
        if (s.length() < 2 || s.length() > 120) return false;

        String l = s.toLowerCase(Locale.US);
        String[] bad = {
                "facebook", "trang", "page", "bài viết", "bai viet",
                "home", "feed", "reels", "video", "photos", "menu",
                "bạn đang nghĩ gì", "ban dang nghi gi", "what's on your mind"
        };
        for (String b : bad) if (l.equals(b)) return false;

        if (s.matches("(?i)^https?://.*$")) return false;
        if (s.matches(".*\\b(?:giờ|phút|hour|minutes)\\b.*")) return false;
        return true;
    }

    private boolean isSpecificFacebookPageUrl(String value) {
        if (value == null || !isFacebookUrl(value)) return false;
        String s = value.trim().toLowerCase(Locale.US);
        return s.matches("^https?://(?:www\\.)?facebook\\.com/pages/[^/]+/\\d{5,30}(?:/.*)?$")
                || s.matches("^https?://(?:www\\.)?facebook\\.com/[^/?#]+[?&](?:id|page_id)=\\d{5,30}(?:&.*)?$");
    }

    private String inferPageNameFromFacebookUrl(String value) {
        if (value == null || !isFacebookUrl(value)) return "";
        try {
            android.net.Uri u = android.net.Uri.parse(value);
            String path = u.getPath() == null ? "" : u.getPath();
            java.util.regex.Matcher m = Pattern.compile("(?i)^/pages/([^/]+)/\\d{5,30}(?:/.*)?$").matcher(path);
            if (m.matches()) return cleanUiText(m.group(1).replace('-', ' '));
        } catch (Throwable ignored) {}
        return "";
    }

    private String extractPageName(String raw) {
        if (raw == null) return "";
        String s = cleanUiText(raw);
        String[] patterns = {
            "(?i).*?(?:đang sử dụng facebook với tư cách|đang dùng facebook với tư cách|sử dụng facebook với tư cách|dùng facebook với tư cách)[:\\s]+(.+)$",
            "(?i).*?(?:using facebook as|continue as)[:\\s]+(.+)$",
            "(?i).*?(?:trang hiện tại|page hiện tại|current page)[:\\s]+(.+)$"
        };
        for (String p : patterns) {
            java.util.regex.Matcher m=Pattern.compile(p).matcher(s);
            if(m.matches()) return cleanUiText(m.group(1));
        }
        return "";
    }

    private int pageNameScore(String raw, String name) {
        String s=raw.toLowerCase(Locale.US);
        int score=0;
        if(s.contains("đang sử dụng facebook với tư cách") || s.contains("đang dùng facebook với tư cách")) score+=100;
        if(s.contains("using facebook as")) score+=90;
        if(s.contains("trang hiện tại") || s.contains("page hiện tại")) score+=80;
        if(name.length()>=2 && name.length()<=120) score+=10;
        return score;
    }

    private boolean containsPageContextSignal(ArrayList<String> texts) {
        return hasActivePageContextSignal(texts);
    }

    private String cleanUiText(String s){
        if(s==null) return "";
        return s.replaceAll("\\s+"," ").trim();
    }

    private String extractPageId(ArrayList<String> texts, String... urls) {
        try {
            Pattern p = Pattern.compile("(?i)(?:page\\s*(?:id|identifier)|id\\s*trang|id\\s*page)\\s*[:#]?\\s*(\\d{5,30})");
            for (String t : texts) {
                if (t == null) continue;
                java.util.regex.Matcher m = p.matcher(t);
                if (m.find()) return m.group(1);
            }
            Pattern u = Pattern.compile("(?i)/pages/[^/]+/(\\d{5,30})(?:/|$)");
            Pattern q = Pattern.compile("(?i)[?&](?:id|page_id)=(\\d{5,30})(?:&|$)");
            for (String url : urls) {
                if (url == null) continue;
                java.util.regex.Matcher m = u.matcher(url);
                if (m.find()) return m.group(1);
                m = q.matcher(url);
                if (m.find()) return m.group(1);
            }

            // Some Facebook accessibility nodes expose complete href-like
            // strings even when the omnibox is only facebook.com.
            for (String t : texts) {
                if (t == null) continue;
                java.util.regex.Matcher m = u.matcher(t);
                if (m.find()) return m.group(1);
                m = q.matcher(t);
                if (m.find()) return m.group(1);
            }
        } catch (Throwable ignored) {}
        return "";
    }

    private void savePageId(String value){
        try{ getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(PREF_LAST_PAGE_ID,value).apply(); }catch(Throwable ignored){}
    }
    private String getSavedPageId(){
        try{return getSharedPreferences(PREFS,MODE_PRIVATE).getString(PREF_LAST_PAGE_ID,"");}catch(Throwable ignored){return "";}
    }

    private void savePageName(String value){
        try{ getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(PREF_LAST_PAGE_NAME,value).apply(); }catch(Throwable ignored){}
    }
    private String getSavedPageName(){
        try{return getSharedPreferences(PREFS,MODE_PRIVATE).getString(PREF_LAST_PAGE_NAME,"");}catch(Throwable ignored){return "";}
    }

    private void updateChromeUrl(String value) {
        String url = normalizeUrl(value);

        if (url.isEmpty()) return;

        /*
         * Facebook mobile can briefly expose /login/identify, /home, /
         * or another shell URL while the already-rendered Page remains on
         * screen. Never destroy a previously captured specific Page URL with
         * one of these generic Facebook routes.
         */
        if (isFacebookUrl(url) && isGenericFacebookRoute(url)) {
            String saved = getSavedPageUrl();
            if (isSpecificPageUrl(saved)) {
                url = saved;
            } else if (isSpecificPageUrl(lastUrl)) {
                url = lastUrl;
            }
        }

        boolean changed = !url.equals(lastUrl)
                || facebookDetected != isFacebookUrl(url);

        long now = System.currentTimeMillis();
        beginOrKeepChromeSession(now);

        lastPackage = CHROME;
        lastUrl = url;
        lastChromeTime = now;

        // IMPORTANT: Once Facebook has been detected in this Chrome session,
        // changing to another Chrome tab must NOT make Facebook disappear.
        // It is cleared only when a genuinely new Chrome session starts.
        if (isFacebookUrl(url)) {
            facebookSeenInChromeSession = true;
        }
        facebookDetected = facebookSeenInChromeSession;

        if (isSpecificPageUrl(url)) {
            pageUrl = url;
            savePageUrl(url);
        }

        // Push a changed Chrome/Facebook URL immediately. The regular
        // heartbeat remains as a fallback, but navigation should not wait
        // 15 seconds before Panel sees the new Facebook Page URL.
        if (changed) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    AgentSync.heartbeat(PostFlowAccessibilityService.this);
                }
            }, "PostFlowUrlSync").start();
        }
    }

    private boolean isGenericFacebookRoute(String value) {
        try {
            android.net.Uri uri = android.net.Uri.parse(value);
            String path = uri.getPath() == null ? "" : uri.getPath().trim();
            String first = path.replaceFirst("^/", "").split("/", 2)[0].toLowerCase(Locale.US);
            return first.isEmpty()
                    || "login".equals(first)
                    || "recover".equals(first)
                    || "home".equals(first)
                    || "watch".equals(first)
                    || "reels".equals(first)
                    || "groups".equals(first)
                    || "pages".equals(first)
                    || "messages".equals(first)
                    || "notifications".equals(first)
                    || "friends".equals(first)
                    || "settings".equals(first)
                    || "search".equals(first)
                    || "marketplace".equals(first);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean isSpecificPageUrl(String value) {
        if (!isFacebookUrl(value)) return false;
        try {
            android.net.Uri uri = android.net.Uri.parse(value);
            String path = uri.getPath() == null ? "" : uri.getPath().trim();
            if (path.isEmpty() || "/".equals(path)) return false;
            String clean = path.replaceFirst("^/", "");
            String first = clean.split("/", 2)[0].toLowerCase(Locale.US);
            if ("groups".equals(first) || "login".equals(first) || "recover".equals(first)
                    || "home".equals(first) || "watch".equals(first) || "reels".equals(first)
                    || "videos".equals(first) || "marketplace".equals(first) || "events".equals(first)
                    || "gaming".equals(first) || "messages".equals(first) || "notifications".equals(first)
                    || "friends".equals(first) || "settings".equals(first) || "search".equals(first)) return false;
            return clean.matches("(?i)^(?:pages/[^/]+(?:/[0-9]+)?|pg/[^/]+|profile\\.php(?:/|$)|[^/]+(?:/.*)?)$");
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void savePageUrl(String url) {
        try {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(PREF_LAST_PAGE_URL, url)
                    .apply();
        } catch (Throwable ignored) {}
    }

    private String getSavedPageUrl() {
        try {
            return getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(PREF_LAST_PAGE_URL, "");
        } catch (Throwable ignored) {
            return "";
        }
    }

    private String normalizeUrl(String value) {
        if (value == null) return "";

        String s = value.trim();

        if (s.isEmpty()) return "";

        if (!s.matches("(?i)^https?://.*")) {
            if (s.matches("(?i)^(?:www\\.)?(?:[a-z0-9-]+\\.)*facebook\\.com(?:/.*)?$")) {
                return "https://" + s;
            }
        }

        return s;
    }

    private boolean isFacebookUrl(String value) {
        if (value == null) return false;

        String s = value.trim();

        if (s.isEmpty()) return false;

        return FACEBOOK_URL.matcher(s).matches();
    }

    private void expireStaleState() {
        long now = System.currentTimeMillis();

        if (CHROME.equals(lastPackage)
                && lastChromeTime > 0
                && now - lastChromeTime > STATE_TIMEOUT_MS) {

            // Before declaring Chrome gone, inspect the currently visible
            // accessibility windows. Switching Chrome tabs or briefly leaving
            // the Agent must never clear the session.
            boolean chromeStillVisible = false;
            try {
                List<AccessibilityWindowInfo> windows = getWindows();
                if (windows != null) {
                    for (AccessibilityWindowInfo w : windows) {
                        if (w == null) continue;
                        AccessibilityNodeInfo r = null;
                        try {
                            r = w.getRoot();
                            if (r != null && CHROME.equals(packageName(r))) {
                                chromeStillVisible = true;
                                break;
                            }
                        } catch (Throwable ignored) {
                        } finally {
                            if (r != null) try { r.recycle(); } catch (Throwable ignored) {}
                        }
                    }
                }
            } catch (Throwable ignored) {}

            if (!chromeStillVisible) {
                lastPackage = "";
                lastUrl = "";
            }

            facebookDetected = facebookSeenInChromeSession;
        }
    }

    public static void requestPageGroupScan() {
        final PostFlowAccessibilityService s = INSTANCE;
        if (s == null || !isRunning) return;
        s.handler.post(new Runnable() {
            @Override public void run() {
                s.manualPageGroupScanRequested = true;
                s.discoveredGroups.clear();
                s.visibleGroupsJson = "[]";
                s.groupContextTrusted = false;
                s.groupContextWasPageSpecific = false;
                s.pageGroupsNavigationAttempted = false;
                s.pageGroupsVerifyAttempts = 0;
                s.groupDiscoveryOwner = "PAGE";
                s.groupDiscoveryRunning = false;
                s.lastGroupDiscoveryAt = 0L;
                if (s.pageDetected && s.isChromeActive()) {
                    s.scheduleAutomaticPageGroupDiscovery();
                }
            }
        });
    }

    public static boolean isChromeActive() {
        long now = System.currentTimeMillis();

        return CHROME.equals(lastPackage)
                && lastChromeTime > 0
                && now - lastChromeTime <= STATE_TIMEOUT_MS;
    }

    public static boolean isFacebookActive() {
        return isChromeActive() && facebookDetected;
    }
    public static boolean isPageDetected() {
        return isChromeActive() && pageDetected;
    }

    public static String currentPageName() { return pageName == null ? "" : pageName; }
    public static String currentPageUrl() { return pageUrl == null ? "" : pageUrl; }
    public static String currentPageId() { return pageId == null ? "" : pageId; }
    public static String currentFacebookMode() { return facebookMode == null ? "UNKNOWN" : facebookMode; }
    public static String currentVisibleGroupsJson() { return visibleGroupsJson == null ? "[]" : visibleGroupsJson; }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        // Activity lifecycle is independent from AccessibilityService.
        // Returning true lets Android call onRebind() if it reconnects the service.
        isRunning = false;
        handler.removeCallbacks(poller);
        handler.removeCallbacks(heartbeat);
        handler.removeCallbacks(commandPoller);
        return true;
    }

    @Override
    public void onRebind(android.content.Intent intent) {
        super.onRebind(intent);
        onServiceConnected();
    }

    @Override
    public void onInterrupt() {
        // Accessibility interruption is not the same as the permission being disabled.
        // Do not clear Facebook/Page state here. Android owns the service lifecycle.
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(poller);
        handler.removeCallbacks(heartbeat);
        handler.removeCallbacks(commandPoller);

        // Do not clear persisted Page/Facebook context here. onDestroy() can
        // happen because Android is recycling the service process; it does
        // not mean the user disabled Accessibility. onServiceConnected()
        // will restore the live service state when Android binds it again.
        isRunning = false;
        if (INSTANCE == this) INSTANCE = null;

        super.onDestroy();
    }
}
