package vn.phutungmaykubota.postflowagent;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Locale;

/**
 * V14 membership-first Group provider.
 *
 * IMPORTANT: this provider does NOT scan Accessibility text, screen content,
 * feed cards, or arbitrary /groups/ links.  The authoritative source is a
 * server-side Facebook membership resolver. The Agent sends only the active
 * identity (PROFILE/PAGE + identifiers) and accepts only structured Group
 * records returned by that resolver.
 *
 * Expected response:
 * {
 *   "ok": true,
 *   "groups": [{"id":"123","name":"Group A","url":"https://www.facebook.com/groups/123/"}]
 * }
 */
public final class GroupMembershipProvider {
    private GroupMembershipProvider() {}

    public static Result fetch(Context context, String ownerType,
                               String pageName, String pageId, String pageUrl) {
        if (context == null) return Result.fail("context_null");
        String token = AgentSync.token(context);
        if (token == null || token.trim().isEmpty()) return Result.fail("agent_token_missing");
        if (!"PAGE".equalsIgnoreCase(ownerType) && !"PROFILE".equalsIgnoreCase(ownerType)) {
            return Result.fail("owner_type_invalid");
        }
        if ("PAGE".equalsIgnoreCase(ownerType)
                && pageName.trim().isEmpty() && pageId.trim().isEmpty() && pageUrl.trim().isEmpty()) {
            return Result.fail("page_identity_missing");
        }

        HttpURLConnection c = null;
        try {
            URL u = new URL(AgentSync.server(context) + "/agent_group_membership.php?action=get");
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            c.setRequestProperty("X-Agent-Token", token);

            String body = "device_id=" + enc(AgentSync.deviceId(context))
                    + "&owner_type=" + enc(ownerType.toUpperCase(Locale.US))
                    + "&page_name=" + enc(pageName)
                    + "&page_id=" + enc(pageId)
                    + "&page_url=" + enc(pageUrl);
            OutputStream out = c.getOutputStream();
            out.write(body.getBytes("UTF-8"));
            out.flush();
            out.close();

            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String response = read(in);
            if (code < 200 || code >= 300) return Result.fail("http_" + code);

            JSONObject root = new JSONObject(response);
            if (!root.optBoolean("ok", false)) {
                return Result.fail(root.optString("error", "membership_unavailable"));
            }

            JSONArray a = root.optJSONArray("groups");
            LinkedHashMap<String, GroupRecord> groups = new LinkedHashMap<>();
            if (a != null) {
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    if (o == null) continue;
                    String url = normalizeGroupUrl(o.optString("url", ""));
                    String id = o.optString("id", "").trim();
                    String name = o.optString("name", "").trim();
                    if (url.isEmpty() || !isGroupUrl(url)) continue;
                    String key = id.isEmpty() ? url : id;
                    if (!groups.containsKey(key)) groups.put(key, new GroupRecord(id, name, url));
                }
            }
            return Result.ok(groups);
        } catch (Exception e) {
            return Result.fail(e.getClass().getSimpleName());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static boolean isGroupUrl(String url) {
        return url.matches("(?i)^https://(?:www\\.)?facebook\\.com/groups/[^/?#]+/?(?:[?#].*)?$");
    }

    private static String normalizeGroupUrl(String value) {
        String s = value == null ? "" : value.trim();
        if (s.isEmpty()) return "";
        if (s.startsWith("http://")) s = "https://" + s.substring(7);
        if (!s.startsWith("https://")) s = "https://" + s;
        if (s.matches("(?i)^https://facebook\\.com/groups/[^/?#]+$")) s += "/";
        return s;
    }

    private static String enc(String s) throws Exception {
        return URLEncoder.encode(s == null ? "" : s, "UTF-8");
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder b = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) b.append(line);
        br.close();
        return b.toString();
    }

    public static final class GroupRecord {
        public final String id;
        public final String name;
        public final String url;
        GroupRecord(String id, String name, String url) {
            this.id = id == null ? "" : id;
            this.name = name == null ? "" : name;
            this.url = url == null ? "" : url;
        }
    }

    public static final class Result {
        public final boolean ok;
        public final String error;
        public final LinkedHashMap<String, GroupRecord> groups;
        private Result(boolean ok, String error, LinkedHashMap<String, GroupRecord> groups) {
            this.ok = ok;
            this.error = error == null ? "" : error;
            this.groups = groups == null ? new LinkedHashMap<String, GroupRecord>() : groups;
        }
        static Result ok(LinkedHashMap<String, GroupRecord> groups) { return new Result(true, "", groups); }
        static Result fail(String error) { return new Result(false, error, null); }
    }
}
