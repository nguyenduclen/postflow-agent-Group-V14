# PostFlow Agent FINAL ALL FIX V5 – Chrome/Facebook Sticky

Fix chính:
- Sau khi Facebook đã được phát hiện trong Chrome, chuyển sang tab Chrome khác không làm mất trạng thái Facebook.
- Không phụ thuộc việc URL tab hiện tại phải còn là facebook.com.
- Giữ Page context đã nhận trong cùng Chrome session.
- Chỉ bắt đầu lại trạng thái Facebook/Page khi service khởi động một Chrome session mới sau khoảng cách dài (30 phút).
- Giữ nguyên các fix trước: Accessibility rebind, Chrome active window, Page detection từ giao diện Facebook.

Test:
1. Bật Accessibility một lần.
2. Mở Chrome -> Facebook và chờ Agent nhận Facebook/Page.
3. Chuyển sang tab Chrome khác. Chờ 1-2 phút. Panel vẫn phải báo Facebook đã phát hiện.
4. Quay lại Facebook: Page tiếp tục được nhận.
5. Đóng hẳn Chrome rồi mở lại để kiểm tra session mới.
