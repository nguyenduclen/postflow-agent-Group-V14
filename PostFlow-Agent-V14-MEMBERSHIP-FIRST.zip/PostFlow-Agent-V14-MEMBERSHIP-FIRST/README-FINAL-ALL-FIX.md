# PostFlow Agent FINAL ALL FIX V6

- AccessibilityService lifecycle rebind support.
- Closing/reopening MainActivity does not require toggling Accessibility again.
- UI distinguishes permission-enabled from service reconnecting.
- Chrome foreground detection uses active/focused application window and remains stable across Chrome tab switches.
- Page detection remains based on Facebook UI context, not only the facebook.com URL.
- Existing group URL capture is preserved; groups are only reported when Facebook exposes group URLs in the accessibility tree.

Important: Android itself can disable an Accessibility service after the user explicitly force-stops the app, uninstalls/reinstalls it, changes certain security settings, or some OEM battery/security features intervene. No normal app can silently re-enable an Accessibility permission that Android has disabled.
