# PostFlow Agent V7.1 FINAL — PAGE → GROUP AUTO + ACCESSIBILITY PERSIST

Bản này sửa thêm lỗi khi đóng Activity/thoát giao diện Agent rồi mở lại: Agent không được coi việc Activity bị đóng là Accessibility bị tắt. Android vẫn quản lý AccessibilityService độc lập.

- `android:stopWithTask="false"`
- kiểm tra Accessibility bằng `Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES` và `AccessibilityManager`
- kiểm tra lại sau khi Activity resume trong 0.5s / 1.5s / 3s để chờ Android reconnect service
- không phụ thuộc `isRunning` để kết luận quyền Accessibility đã bật
- giữ luồng Page → tự discovery Group như V7

Lưu ý: nếu người dùng dùng **Buộc dừng/Force stop** ứng dụng từ Android Settings, Android có thể chặn service cho đến khi người dùng mở lại/cho phép lại theo chính sách của hệ điều hành. Đây không thể được ứng dụng tự vượt qua.

## V7 Access Persistence
- Closing/reopening MainActivity does not disable Accessibility.
- MainActivity checks the authoritative ENABLED_ACCESSIBILITY_SERVICES setting instead of the static service flag.
- AccessibilityService requests Android rebind on temporary unbind/interrupt (API 24+).
- Service onDestroy no longer wipes the live Facebook/Page context just because Android is recycling the service process.
- The UI distinguishes “Accessibility enabled, reconnecting” from “Accessibility disabled”.
