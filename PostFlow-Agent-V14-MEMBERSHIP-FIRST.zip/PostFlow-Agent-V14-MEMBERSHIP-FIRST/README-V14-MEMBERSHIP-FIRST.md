# PostFlow Agent V14 — Membership First

## Mục tiêu

V14 loại bỏ đường `scan text` / `scan screen` để suy đoán Group.

Agent chỉ nhận Group từ một nguồn dữ liệu có cấu trúc: **membership resolver**.
Resolver nhận identity hiện tại (`PAGE` hoặc `PROFILE`) và trả về danh sách Group mà identity đó đã tham gia/liên kết.

## Luồng

```text
Facebook identity
   -> PAGE / PROFILE
   -> membership resolver
   -> group id + name + url
   -> visible_groups_json
   -> PostFlow Panel
```

## Fail-closed

Nếu membership resolver không trả dữ liệu hợp lệ:

```json
{"visible_groups_json":[]}
```

V14 tuyệt đối không fallback sang:

- Accessibility text scanner
- toàn bộ màn hình
- Feed `/groups/...` links
- Group đề xuất
- Group cá nhân khi đang ở PAGE

## Server contract

Agent gọi:

`POST /agent_group_membership.php?action=get`

Header:

`X-Agent-Token: <agent token>`

Body:

- `device_id`
- `owner_type=PAGE|PROFILE`
- `page_name`
- `page_id`
- `page_url`

Response:

```json
{
  "ok": true,
  "groups": [
    {"id":"123","name":"Group A","url":"https://www.facebook.com/groups/123/"}
  ]
}
```

Chỉ URL `facebook.com/groups/<id-or-slug>` được chấp nhận.

> Lưu ý: Android Accessibility permission không tự tạo Facebook Graph/API permission. Endpoint resolver phải lấy membership bằng cơ chế Facebook mà tài khoản/Page đã được cấp quyền hợp lệ. V14 không đọc cookie, mật khẩu hoặc Chrome storage.
